#!/bin/bash
#参数说明，$1 nfs授权网段，$2 keepalived VIP地址，$3 keepalived master or slave ,$4 网卡接口，$5 nfs-slave地址
#slave_ip_address 是从节点的服务器IP，数据同步时需填写
#生成的nfscheck.sh脚本需在nfs客户端执行，目的是当nfs主节点挂了的时候，切到从节点(vip漂移 nfs需重新挂载相关目录)
notice="\033[31;40m参数说明，\$1 nfs授权网段，\$2 keepalived VIP地址，\$3 keepalived master or slave ,\$4 网卡接口，\$5 nfs-slave地址\033[0m"
function init(){
    ip_range=$1
    vip=$2
    status=$3
    interface=$4
    rsync_password="uW4^d9%EtU*2"
    slave_ip_address="${5}"
    nfs_dir1="/data/solarnfs/logs"
    nfs_dir2="/data/solarnfs/download"
    nfs_dir3="/data/solarnfs/qrcodecheck"
    mkdir -pv ${nfs_dir1} ${nfs_dir2} ${nfs_dir3}
    yum -y install nfs-utils keepalived rsync
    vir_id="123"


cat > /etc/exports <<EOF
/data/solarnfs/logs   ${ip_range}(rw,no_root_squash,no_all_squash,sync,anonuid=501,anongid=501)
/data/solarnfs/download   ${ip_range}(rw,no_root_squash,no_all_squash,sync,anonuid=501,anongid=501)
/data/solarnfs/qrcodecheck   ${ip_range}(rw,no_root_squash,no_all_squash,sync,anonuid=501,anongid=501)
EOF

systemctl enable nfs-server ; systemctl start nfs-server ; systemctl enable keepalived ; systemctl enable rsyncd

if [ ${status} == "master" ];then
    keepalivedMaster
    rsyncMaster
elif [ ${status} == "slave" ];then
    keepalivedSlave
    rsyncSlave
else
    exit 1
fi  
    
changeNfs
pkill -9 keepalived
systemctl restart keepalived
}


function keepalivedMaster(){

cat > /etc/keepalived/keepalived.conf <<EOF
vrrp_script checkscript {
    script "/bin/bash -c '[[ -e /etc/keepalived/down ]]' && exit 1 || exit 0 "
    interval 1
    fall 3
    rise 2
    weight -5
    timeout 1
}

vrrp_instance VI_1 {

track_script {
    checkscript
}
    state MASTER
    interface ${interface}
    virtual_router_id ${vir_id}
    priority 100
    advert_int 1
    authentication {
        auth_type PASS
        auth_pass rabbit
    }
    virtual_ipaddress {
    ${vip}
    }
}
EOF
}

function keepalivedSlave(){

cat > /etc/keepalived/keepalived.conf <<EOF
vrrp_script checkscript {
        script "/bin/bash -c '[[ -e /etc/keepalived/down ]]' && exit 1 || exit 0 "
        interval 1
        fall 3
        rise 2
        weight -5
        timeout 1
}

vrrp_instance VI_1 {

track_script {
        checkscript
}
    state BACKUP
    interface ${interface}
    virtual_router_id ${vir_id}
    priority 98
    advert_int 1
    authentication {
        auth_type PASS
        auth_pass rabbit
    }
    virtual_ipaddress {
        ${vip}
    }
}
EOF
}

#网络探测，避免网络问题
function networkCheck(){
network_gateway=`route -n | awk '/^0.0.0.0/{print $2}'`
cp /var/spool/cron/root{,.bak} &>/dev/null
cat >> /var/spool/cron/root <<EOF
`cat /var/spool/cron/root.bak`
*/1 * * * * /usr/bin/ping ${network_gateway} -c 1 -W 1 &>/dev/null && rm -f /etc/keepalived/down  || touch /etc/keepalived/down
EOF
}

#nfs切换脚本
function changeNfs(){
cat > nfscheck.sh <<EOF
#!/bin/bash

function check(){
mkdir -pv ${nfs_dir1} ${nfs_dir2} ${nfs_dir3}
while true;do
    #判断是否为本机
    ip a | egrep "${vip}"
    if [ \$? -ne 0 ];then
        ls /data/solarnfs/logs &>/dev/null
        if [ \$? -ne 0 ];then
            umount -f ${nfs_dir1}
            umount -f ${nfs_dir2}
            umount -f ${nfs_dir3}

            mount ${vip}:${nfs_dir1} ${nfs_dir1}
            mount ${vip}:${nfs_dir2} ${nfs_dir2}
            mount ${vip}:${nfs_dir3} ${nfs_dir3}
        fi
    else
        continue

    fi
    sleep 10
done
}
pkill -9 nfscheck.sh
check
EOF
chmod a+x nfscheck.sh
}



function rsyncSlave(){
cat > /etc/rsyncd.conf <<EOF
uid = nfsnobody
gid = nfsnobody
port = 873
pid file = /var/rsyncd.pid
log file = /var/log/rsyncd.log
use chroot = no
max connections = 36000
read only = no
ignore errors = yes
auth users = nfs
secrets file = /etc/rsync.pass
hosts allow = ${iprange}
[base]
comment = base
path = /data/solarnfs
EOF
chown -R nfsnobody.nfsnobody /data/solarnfs
echo "nfs:${rsync_password}" > /etc/rsync.pass
chmod 600 /etc/rsync.pass

systemctl restart rsyncd
}

function rsyncMaster(){
echo "${rsync_password}" > /etc/rsync.pass
chmod 600 /etc/rsync.pass
tar -xvf sersync.tar.gz -C /opt
sed -i "s#slaveipaddress#${slave_ip_address}#g" /opt/sersync/confxml.xml
pkill -9 sersync
nohup /opt/sersync/sersync2 -r -d -o /opt/sersync/confxml.xml >/opt/sersync/rsync.log 2>&1 &
chmod a+x /etc/rc.d/rc.local

cat >> a+x /etc/rc.d/rc.local <<EOF
/opt/sersync/sersync2 -r -d -o /opt/sersync/confxml.xml >/opt/sersync/rsync.log 2>&1
EOF
}

function main(){
    iprange=$1
    vip_address=$2
    status=$3
    interface=$4
    slave_address=$5
    init ${iprange} ${vip_address} ${status} ${interface} ${slave_address}
    networkCheck
}

[ $# -ne 5 ] && { echo -e "Usage: $0 [ 192.168.3.0/24 192.168.3.200 master|slave ens33 192.168.3.12 ]\n\t${notice}"  ; exit 1 ; }
main $1 $2 $3 $4 $5
